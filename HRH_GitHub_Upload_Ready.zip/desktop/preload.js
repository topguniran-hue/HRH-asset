// Intentionally minimal: renderer uses the local HTTP API.
