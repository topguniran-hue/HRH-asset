const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const publicDir = path.join(root, 'public');
const outDir = path.join(root, 'dist-web');

fs.rmSync(outDir, { recursive: true, force: true });
fs.cpSync(publicDir, outDir, { recursive: true });
console.log(`Static web build copied to ${outDir}`);
