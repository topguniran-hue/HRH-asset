const fs = require('fs');
const required = [
  'package.json','capacitor.config.json','electron-builder.yml',
  'public/index.html','public/app.js','public/style.css',
  'server/server.js','desktop/main.js','desktop/preload.js'
];
const missing = required.filter(f => !fs.existsSync(f));
if (missing.length) { console.error('Missing files:', missing); process.exit(1); }
console.log('HRH build structure OK');
