@echo off
cd /d %~dp0
where node >nul 2>nul || (echo Node.js 22+ is required.&pause&exit /b 1)
call npm install
call npx cap add android
call npx cap sync android
call npx cap open android
