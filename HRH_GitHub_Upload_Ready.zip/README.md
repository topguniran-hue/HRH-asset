# HRH Asset Manager — Production 1.4

سامانه فارسی و RTL مدیریت اموال، انبار، پرسنل، امانات، خرید و گردش دارایی برای Web / Android / Windows.

## ارتقاهای نسخه 1.4
- داشبورد سازمانی با ارزش دارایی، امانات معوق و اقلام نیازمند رسیدگی
- مدیریت دسته‌بندی و تأمین‌کنندگان
- انتخاب‌گرهای واقعی انبار/مال/پرسنل در فرم‌ها
- شماره‌گذاری خودکار دارایی‌ها با کنترل آخرین کد
- گردش تحویل و برگشت امانت
- جابجایی رسمی بین انبارها و تاریخچه انتقال
- گزارش تفکیکی انبار و دسته و گزارش پرسنلی
- خروجی Excel برای گزارش‌های اصلی
- چاپ/PDF از طریق Print سیستم
- مدیریت کاربران: نقش، فعال/غیرفعال و تغییر رمز
- اصلاح احراز هویت کلاینت و جلوگیری از نمایش اشتباه نقش کاربر
- Backup/Restore نسخه 3
- SQLite + WAL و Audit Log
- رابط Responsive برای موبایل و دسکتاپ

## اجرا
Node.js 22 یا بالاتر لازم است.

```bash
npm install
npm start
```

سپس `http://localhost:3000` را باز کنید.

ورود اولیه: `admin / Admin@12345`

برای امنیت، قبل از استفاده واقعی مقدار `ADMIN_PASSWORD` و `JWT_SECRET` را تنظیم کنید.

## Android
```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

## Windows
```bash
npm install
npm run build:win
```

خروجی Electron در پوشه `dist` قرار می‌گیرد.


## Enterprise 1.4
- Purchase-to-Asset workflow
- Formal handover documents
- Digital signature capture
- Approval audit trail
- Enterprise tables for purchase items, signatures, documents and approvals
- Android/Windows packaging configuration retained

Security note: set `JWT_SECRET` and `ADMIN_PASSWORD` in production; the default credentials are for first-run only.

## GitHub Actions — Build خودکار

سه Workflow در `.github/workflows/` قرار دارد:

- `android.yml`: ساخت Debug APK، Release APK و Release AAB
- `windows.yml`: ساخت Windows NSIS Installer و Portable EXE
- `release.yml`: Build خروجی‌های Android هنگام ایجاد Tag با الگوی `v*`

### روش استفاده
1. کل پروژه را در یک Repository خصوصی یا عمومی GitHub قرار دهید.
2. در GitHub به **Actions** بروید.
3. Workflow موردنظر را انتخاب و **Run workflow** کنید.
4. خروجی‌ها در بخش **Artifacts** قابل دریافت هستند.
5. برای Release خودکار:
   ```bash
   git tag v1.4.1
   git push origin v1.4.1
   ```

### امضای Android
Workflow فعلی APK/AAB را بدون کلید انتشار می‌سازد. برای انتشار رسمی در Google Play باید Android Keystore در GitHub Secrets ذخیره و مرحله signing به Workflow اضافه شود. کلید خصوصی را داخل Repository قرار ندهید.

### امنیت
`JWT_SECRET` و `ADMIN_PASSWORD` را در محیط اجرای سرور تنظیم کنید و رمز پیش‌فرض را تغییر دهید.
