# Android build target

این پوشه برای پروژه Native تولیدشده توسط Capacitor رزرو شده است.

از ریشه پروژه اجرا کنید:
`npx cap add android`
`npx cap sync android`

در Android Studio پروژه `android/` را باز کرده و APK/AAB بسازید.
اپلیکیشن در صورت نبودن API مرکزی، به‌صورت local/offline با localStorage کار می‌کند؛ در حالت LAN/VPS می‌تواند API مرکزی را مصرف کند.
